"use client";

import React, { useState, useRef } from "react";
import Link from "next/link";
import WhatsAppButton from "@/components/WhatsAppButton";

export default function Terms() {
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const mobileNavRef = useRef();

  // Close mobile nav on outside click
  React.useEffect(() => {
    if (!mobileNavOpen) return;
    function handleClick(e) {
      if (mobileNavRef.current && !mobileNavRef.current.contains(e.target)) {
        setMobileNavOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, [mobileNavOpen]);

  return (
    <div className="min-h-screen flex flex-col">
      {/* Mobile Nav Button */}
      <div className="flex justify-between flex-row-reverse dir-rtl items-center px-4 pt-6 md:hidden">
        <button
          className="p-2 rounded focus:outline-none focus:ring-2 focus:ring-orange-400"
          aria-label="Open navigation menu"
          onClick={() => setMobileNavOpen(true)}
        >
          <svg className="w-8 h-8" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
        <div className="flex items-center">
          <img src="/logo.png" alt="logo" className="w-12 h-12" />
        </div>
      </div>

      {/* Desktop Nav */}
      <div className="hidden md:block w-full">
        <div className="max-w-7xl mx-auto w-full flex justify-between flex-row-reverse dir-rtl items-center px-10 pt-8">
          <div className="flex gap-10 text-lg font-medium">
            <Link href="/" className="hover:underline">الرئيسية</Link>
            <Link href="/about" className="hover:underline">من نحن</Link>
            <Link href="/delivery" className="hover:underline">الشحن والإرجاع</Link>
            <Link href="/privacy" className="hover:underline">سياسة الخصوصية</Link>
            <Link href="/terms" className="hover:underline font-bold">الشروط والأحكام</Link>
          </div>
          <div className="flex items-center w-[100px] h-[100px]">
            <img src="/logo.png" alt="logo" className="object-contain" />
          </div>
        </div>
      </div>

      {/* Mobile Nav Drawer */}
      <div
        ref={mobileNavRef}
        className={`fixed top-0 right-0 z-50 h-full w-64 bg-white text-orange-900 shadow-lg transform transition-transform duration-300 ease-in-out
          ${mobileNavOpen ? 'translate-x-0' : 'translate-x-full'}
          md:hidden dir-rtl flex flex-col`}
        style={{ fontFamily: 'inherit' }}
      >
        <div className="flex justify-between items-center p-4 border-b border-orange-100">
          <div className="flex items-center">
            <img src="/logo.png" alt="logo" className="w-12 h-12" />
          </div>
          <button
            className="p-2 rounded focus:outline-none focus:ring-2 focus:ring-orange-400"
            aria-label="Close navigation menu"
            onClick={() => setMobileNavOpen(false)}
          >
            <svg className="w-7 h-7" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <nav className="flex flex-col gap-6 text-lg font-medium p-6">
          <Link href="/" className="hover:text-orange-600 transition" onClick={() => setMobileNavOpen(false)}>الرئيسية</Link>
          <Link href="/about" className="hover:text-orange-600 transition" onClick={() => setMobileNavOpen(false)}>من نحن</Link>
          <Link href="/delivery" className="hover:text-orange-600 transition" onClick={() => setMobileNavOpen(false)}>الشحن والإرجاع</Link>
          <Link href="/privacy" className="hover:text-orange-600 transition" onClick={() => setMobileNavOpen(false)}>سياسة الخصوصية</Link>
          <Link href="/terms" className="hover:text-orange-600 transition font-bold" onClick={() => setMobileNavOpen(false)}>الشروط والأحكام</Link>
        </nav>
      </div>

      {/* Overlay when menu is open */}
      {mobileNavOpen && (
        <div
          className="fixed inset-0 z-40 bg-black bg-opacity-30 transition-opacity duration-300 md:hidden"
          onClick={() => setMobileNavOpen(false)}
        />
      )}

      {/* Main Content */}
      <div className="flex-1 bg-white">
        <div className="max-w-4xl mx-auto px-4 py-12">
          <div className="text-center mb-12">
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">الشروط والأحكام</h1>
            <div className="w-24 h-1 bg-orange-600 mx-auto"></div>
            <p className="text-gray-600 mt-4">عقد البيع عن بعد - آخر تحديث: يناير 2025</p>
          </div>

          {/* Contract Parties */}
          <div className="bg-gray-50 rounded-lg p-8 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">أطراف العقد</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-white rounded-lg p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-3">البائع</h3>
                <div className="space-y-2 text-gray-600">
                  <p><strong>الاسم:</strong> منصة اكتفاء</p>
                  <p><strong>العنوان:</strong> نيروبي، كينيا</p>
                  <p><strong>البريد الإلكتروني:</strong> info@alsaheilalaw.com</p>
                  <p><strong>الهاتف:</strong> +254 750 963094</p>
                </div>
              </div>
              <div className="bg-white rounded-lg p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-3">المشتري</h3>
                <div className="space-y-2 text-gray-600">
                  <p>سيتم تحديد بيانات المشتري عند إتمام الطلب</p>
                  <p>يشمل: الاسم، البريد الإلكتروني، رقم الهاتف، البلد</p>
                </div>
              </div>
            </div>
          </div>

          {/* Product Information */}
          <div className="bg-white border border-gray-200 rounded-lg p-8 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">معلومات المنتجات</h2>
            <div className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-gray-50 rounded-lg p-4">
                  <h4 className="font-bold text-gray-900 mb-2">الأضاحي</h4>
                  <ul className="space-y-1 text-gray-600 text-sm">
                    <li>• خروف: $75 - سنة، صحة ممتازة، 60 كجم</li>
                    <li>• عجل: $450 - سنتين، صحة ممتازة، 200 كجم</li>
                    <li>• جمل: $750 - ثلاث سنوات، صحة ممتازة، 300 كجم</li>
                  </ul>
                </div>
                <div className="bg-gray-50 rounded-lg p-4">
                  <h4 className="font-bold text-gray-900 mb-2">الوجبات والطرود</h4>
                  <ul className="space-y-1 text-gray-600 text-sm">
                    <li>• وجبة: $2</li>
                    <li>• طرد غذائي: حسب الحاجة</li>
                  </ul>
                </div>
              </div>
              <div className="bg-orange-50 rounded-lg p-4">
                <h4 className="font-bold text-gray-900 mb-2">ملاحظات مهمة</h4>
                <ul className="space-y-1 text-gray-600 text-sm">
                  <li>• جميع الأضاحي يتم ذبحها وفق المعايير الشرعية الإسلامية</li>
                  <li>• يتم تنفيذ الأضاحي في دول أفريقيا وتوزيعها على المستحقين</li>
                  <li>• الأسعار تشمل جميع التكاليف (الشراء، الذبح، التوزيع)</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Order and Payment */}
          <div className="bg-orange-50 rounded-lg p-8 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">الطلب والدفع</h2>
            <div className="space-y-6">
              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">طريقة الطلب</h3>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 bg-orange-600 rounded-full flex items-center justify-center text-white text-sm font-bold">1</div>
                    <span className="text-gray-700">اختيار المنتجات المطلوبة من الموقع</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 bg-orange-600 rounded-full flex items-center justify-center text-white text-sm font-bold">2</div>
                    <span className="text-gray-700">ملء البيانات الشخصية</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 bg-orange-600 rounded-full flex items-center justify-center text-white text-sm font-bold">3</div>
                    <span className="text-gray-700">الدفع عبر بوابة الدفع الآمنة (iyzico)</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 bg-orange-600 rounded-full flex items-center justify-center text-white text-sm font-bold">4</div>
                    <span className="text-gray-700">تأكيد الطلب وإرسال التفاصيل</span>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">طرق الدفع</h3>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="bg-white rounded-lg p-4">
                    <h4 className="font-bold text-gray-900 mb-2">البطاقات الائتمانية</h4>
                    <p className="text-gray-600 text-sm">Visa, MasterCard, American Express</p>
                  </div>
                  <div className="bg-white rounded-lg p-4">
                    <h4 className="font-bold text-gray-900 mb-2">الدفع الإلكتروني</h4>
                    <p className="text-gray-600 text-sm">PayPal, المحافظ الإلكترونية</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right of Withdrawal */}
          <div className="bg-white border border-gray-200 rounded-lg p-8 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">حق الانسحاب</h2>
            <div className="space-y-6">
              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">شروط الانسحاب</h3>
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <svg className="w-6 h-6 text-green-600 mt-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <div>
                      <h4 className="font-bold text-gray-900 mb-1">قبل التنفيذ</h4>
                      <p className="text-gray-600 text-sm">يمكن طلب الانسحاب والاسترداد الكامل قبل بدء عملية الذبح</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <svg className="w-6 h-6 text-red-600 mt-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                    <div>
                      <h4 className="font-bold text-gray-900 mb-1">بعد التنفيذ</h4>
                      <p className="text-gray-600 text-sm">لا يمكن الانسحاب بعد بدء عملية الذبح أو التوزيع</p>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">إجراءات الانسحاب</h3>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-orange-600 rounded-full flex items-center justify-center text-white font-bold">1</div>
                    <span className="text-gray-700">تواصل معنا عبر البريد الإلكتروني أو الهاتف</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-orange-600 rounded-full flex items-center justify-center text-white font-bold">2</div>
                    <span className="text-gray-700">قدم رقم الطلب وسبب الانسحاب</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-orange-600 rounded-full flex items-center justify-center text-white font-bold">3</div>
                    <span className="text-gray-700">سنراجع طلبك ونوافيك بالنتيجة خلال 24 ساعة</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-orange-600 rounded-full flex items-center justify-center text-white font-bold">4</div>
                    <span className="text-gray-700">في حالة الموافقة، سيتم الاسترداد خلال 5-7 أيام عمل</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Seller Obligations */}
          <div className="bg-green-50 rounded-lg p-8 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">التزامات البائع</h2>
            <div className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-white rounded-lg p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-3">التنفيذ</h3>
                  <ul className="space-y-2 text-gray-600">
                    <li className="flex items-start gap-2">
                      <span className="text-green-600 mt-1">•</span>
                      <span>ذبح الأضاحي وفق المعايير الشرعية</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-green-600 mt-1">•</span>
                      <span>توزيع الأضاحي على المستحقين</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-green-600 mt-1">•</span>
                      <span>التوثيق بالصور والفيديو</span>
                    </li>
                  </ul>
                </div>
                <div className="bg-white rounded-lg p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-3">التواصل</h3>
                  <ul className="space-y-2 text-gray-600">
                    <li className="flex items-start gap-2">
                      <span className="text-green-600 mt-1">•</span>
                      <span>إرسال تأكيد الطلب</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-green-600 mt-1">•</span>
                      <span>إشعارات حالة التنفيذ</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-green-600 mt-1">•</span>
                      <span>إرسال تقرير التنفيذ النهائي</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* Buyer Obligations */}
          <div className="bg-blue-50 rounded-lg p-8 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">التزامات المشتري</h2>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <svg className="w-6 h-6 text-blue-600 mt-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <div>
                  <h4 className="font-bold text-gray-900 mb-1">تقديم معلومات صحيحة</h4>
                  <p className="text-gray-600 text-sm">يجب تقديم بيانات شخصية صحيحة وكاملة</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <svg className="w-6 h-6 text-blue-600 mt-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
                </svg>
                <div>
                  <h4 className="font-bold text-gray-900 mb-1">الدفع</h4>
                  <p className="text-gray-600 text-sm">الالتزام بدفع المبلغ المطلوب بالكامل</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <svg className="w-6 h-6 text-blue-600 mt-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                </svg>
                <div>
                  <h4 className="font-bold text-gray-900 mb-1">التواصل</h4>
                  <p className="text-gray-600 text-sm">الرد على استفساراتنا بخصوص الطلب</p>
                </div>
              </div>
            </div>
          </div>

          {/* Dispute Resolution */}
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-8 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">حل النزاعات</h2>
            <div className="space-y-4">
              <p className="text-gray-700">
                في حالة حدوث أي نزاع بين الطرفين، سيتم حله بالطرق التالية:
              </p>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-6 h-6 bg-yellow-600 rounded-full flex items-center justify-center text-white text-sm font-bold">1</div>
                  <span className="text-gray-700">المفاوضة المباشرة بين الطرفين</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-6 h-6 bg-yellow-600 rounded-full flex items-center justify-center text-white text-sm font-bold">2</div>
                  <span className="text-gray-700">الوساطة من خلال مؤسسة محايدة</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-6 h-6 bg-yellow-600 rounded-full flex items-center justify-center text-white text-sm font-bold">3</div>
                  <span className="text-gray-700">اللجوء للقضاء في كينيا</span>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Information */}
          <div className="bg-gray-50 rounded-lg p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">معلومات الاتصال</h2>
            <p className="text-gray-600 mb-6">
              للاستفسارات حول هذه الشروط والأحكام، يرجى التواصل معنا:
            </p>
            <div className="space-y-3">

              <div className="flex items-center gap-3">
                <svg className="w-5 h-5 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                </svg>
                <span className="text-gray-700">الهاتف: +254 750 963094</span>
              </div>
              <div className="flex items-center gap-3">
                <svg className="w-5 h-5 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
                <span className="text-gray-700">العنوان: نيروبي، كينيا</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-[#e8771b] text-white pt-10 pb-2 px-4 mt-auto">
        <div className="max-w-4xl mx-auto flex flex-col items-center text-center">
          <img src="/logo.png" alt="logo" className="w-20 h-20 mb-4 opacity-80" />
          <div className="mb-2 text-base font-normal leading-relaxed">
            تم تنفيذ هذه الخدمة من خلال شراكات موثوقة مع مؤسسات خيرية معتمدة في أفريقيا، بإشراف شرعي وقانوني.<br/>
            نحن نضمن تنفيذ الأضحية في وقتها الشرعي، وإيصالها للمستحقين بأعلى معايير الجودة والشفافية.
          </div>
          
          {/* Payment Methods */}
          <div className="flex items-center justify-center gap-4 mb-6">
            <div className="bg-white rounded-lg p-2">
              <img src="/Visa-Logo.png" alt="Visa" className="h-8 w-auto" />
            </div>
            <div className="bg-white rounded-lg p-2">
              <img src="/Mastercard-logo.svg" alt="MasterCard" className="h-8 w-auto" />
            </div>
            <div className="bg-white rounded-lg p-2">
              <img src="/pay_with_iyzico_colored.png" alt="Pay with iyzico" className="h-8 w-auto" />
            </div>
          </div>
          
          <hr className="w-full border-t border-white/60 my-6" />
          
          {/* Footer Links */}
          <div className="flex flex-wrap justify-center gap-6 mb-4 text-sm">
            <a href="/about" className="hover:underline">من نحن</a>
            <a href="/delivery" className="hover:underline">الشحن والإرجاع</a>
            <a href="/privacy" className="hover:underline">سياسة الخصوصية</a>
            <a href="/terms" className="hover:underline">الشروط والأحكام</a>
          </div>
          
          <div className="flex items-center justify-center gap-6 mb-4 text-base">
            <div className="flex items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h2.28a2 2 0 011.7 1.06l.94 1.88a2 2 0 001.7 1.06h2.28a2 2 0 011.7-1.06l.94-1.88A2 2 0 0118.72 3H21a2 2 0 012 2v14a2 2 0 01-2 2h-2.28a2 2 0 01-1.7-1.06l-.94-1.88a2 2 0 00-1.7-1.06h-2.28a2 2 0 00-1.7 1.06l-.94-1.88A2 2 0 015.28 21H3a2 2 0 01-2-2V5z" /></svg>
              +254 750 963094
            </div>
          </div>
          <div className="text-sm mt-2 opacity-90">كافة الحقوق محفوظة لمنصة اكتفاء 2025 ©</div>
        </div>
      </footer>

      {/* WhatsApp Button */}
      <WhatsAppButton />
    </div>
  );
} 