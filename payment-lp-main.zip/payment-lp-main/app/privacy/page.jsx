"use client";

import React, { useState, useRef } from "react";
import Link from "next/link";
import WhatsAppButton from "@/components/WhatsAppButton";
export default function Privacy() {
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const mobileNavRef = useRef();

  // Close mobile nav on outside click
  React.useEffect(() => {
    if (!mobileNavOpen) return;
    function handleClick(e) {
      if (mobileNavRef.current && !mobileNavRef.current.contains(e.target)) {
        setMobileNavOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, [mobileNavOpen]);

  return (
    <div className="min-h-screen flex flex-col">
      {/* Mobile Nav Button */}
      <div className="flex justify-between flex-row-reverse dir-rtl items-center px-4 pt-6 md:hidden">
        <button
          className="p-2 rounded focus:outline-none focus:ring-2 focus:ring-orange-400"
          aria-label="Open navigation menu"
          onClick={() => setMobileNavOpen(true)}
        >
          <svg className="w-8 h-8" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
        <div className="flex items-center">
          <img src="/logo.png" alt="logo" className="w-12 h-12" />
        </div>
      </div>

      {/* Desktop Nav */}
      <div className="hidden md:block w-full">
        <div className="max-w-7xl mx-auto w-full flex justify-between flex-row-reverse dir-rtl items-center px-10 pt-8">
          <div className="flex gap-10 text-lg font-medium">
            <Link href="/" className="hover:underline">الرئيسية</Link>
            <Link href="/about" className="hover:underline">من نحن</Link>
            <Link href="/delivery" className="hover:underline">الشحن والإرجاع</Link>
            <Link href="/privacy" className="hover:underline font-bold">سياسة الخصوصية</Link>
            <Link href="/terms" className="hover:underline">الشروط والأحكام</Link>
          </div>
          <div className="flex items-center w-[100px] h-[100px]">
            <img src="/logo.png" alt="logo" className="object-contain" />
          </div>
        </div>
      </div>

      {/* Mobile Nav Drawer */}
      <div
        ref={mobileNavRef}
        className={`fixed top-0 right-0 z-50 h-full w-64 bg-white text-orange-900 shadow-lg transform transition-transform duration-300 ease-in-out
          ${mobileNavOpen ? 'translate-x-0' : 'translate-x-full'}
          md:hidden dir-rtl flex flex-col`}
        style={{ fontFamily: 'inherit' }}
      >
        <div className="flex justify-between items-center p-4 border-b border-orange-100">
          <div className="flex items-center">
            <img src="/logo.png" alt="logo" className="w-12 h-12" />
          </div>
          <button
            className="p-2 rounded focus:outline-none focus:ring-2 focus:ring-orange-400"
            aria-label="Close navigation menu"
            onClick={() => setMobileNavOpen(false)}
          >
            <svg className="w-7 h-7" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <nav className="flex flex-col gap-6 text-lg font-medium p-6">
          <Link href="/" className="hover:text-orange-600 transition" onClick={() => setMobileNavOpen(false)}>الرئيسية</Link>
          <Link href="/about" className="hover:text-orange-600 transition" onClick={() => setMobileNavOpen(false)}>من نحن</Link>
          <Link href="/delivery" className="hover:text-orange-600 transition" onClick={() => setMobileNavOpen(false)}>الشحن والإرجاع</Link>
          <Link href="/privacy" className="hover:text-orange-600 transition font-bold" onClick={() => setMobileNavOpen(false)}>سياسة الخصوصية</Link>
          <Link href="/terms" className="hover:text-orange-600 transition" onClick={() => setMobileNavOpen(false)}>الشروط والأحكام</Link>
        </nav>
      </div>

      {/* Overlay when menu is open */}
      {mobileNavOpen && (
        <div
          className="fixed inset-0 z-40 bg-black bg-opacity-30 transition-opacity duration-300 md:hidden"
          onClick={() => setMobileNavOpen(false)}
        />
      )}

      {/* Main Content */}
      <div className="flex-1 bg-white">
        <div className="max-w-4xl mx-auto px-4 py-12">
          <div className="text-center mb-12">
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">سياسة الخصوصية</h1>
            <div className="w-24 h-1 bg-orange-600 mx-auto"></div>
            <p className="text-gray-600 mt-4">آخر تحديث: يناير 2025</p>
          </div>

          {/* Introduction */}
          <div className="bg-gray-50 rounded-lg p-8 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">مقدمة</h2>
            <p className="text-gray-600 leading-relaxed mb-4">
              تحترم منصة اكتفاء خصوصية مستخدميها وتلتزم بحماية البيانات الشخصية التي يتم جمعها من خلال موقعنا الإلكتروني. 
              توضح هذه السياسة كيفية جمع واستخدام وحماية معلوماتك الشخصية.
            </p>
            <p className="text-gray-600 leading-relaxed">
              باستخدام موقعنا، فإنك توافق على جمع واستخدام المعلومات وفقاً لهذه السياسة.
            </p>
          </div>

          {/* Information We Collect */}
          <div className="bg-white border border-gray-200 rounded-lg p-8 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">المعلومات التي نجمعها</h2>
            <div className="space-y-6">
              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">المعلومات الشخصية</h3>
                <ul className="space-y-2 text-gray-600">
                  <li className="flex items-start gap-2">
                    <span className="text-orange-600 mt-1">•</span>
                    <span>الاسم الكامل</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-orange-600 mt-1">•</span>
                    <span>عنوان البريد الإلكتروني</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-orange-600 mt-1">•</span>
                    <span>رقم الهاتف</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-orange-600 mt-1">•</span>
                    <span>البلد</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-orange-600 mt-1">•</span>
                    <span>معلومات الدفع (يتم معالجتها من قبل بوابة الدفع الآمنة)</span>
                  </li>
                </ul>
              </div>

              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">معلومات التصفح</h3>
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                  <p className="text-blue-800 font-medium mb-2">ملاحظة مهمة:</p>
                  <p className="text-blue-700 text-sm">
                    نحن <strong>لا نجمع</strong> عناوين IP أو سجل التصفح أو أي بيانات تتبع أخرى. 
                    نحن نحترم خصوصيتك ولا نستخدم أي تقنيات تتبع أو مراقبة لسلوك التصفح.
                  </p>
                </div>
                <p className="text-gray-600 mb-3">
                  المعلومات الوحيدة التي نجمعها هي تلك التي تقدمها لنا مباشرة عند إتمام الطلب:
                </p>
                <ul className="space-y-2 text-gray-600">
                  <li className="flex items-start gap-2">
                    <span className="text-orange-600 mt-1">•</span>
                    <span>المعلومات الشخصية التي تدخلها في النموذج</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-orange-600 mt-1">•</span>
                    <span>تفاصيل الطلب والمنتجات المختارة</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          {/* How We Use Information */}
          <div className="bg-orange-50 rounded-lg p-8 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">كيفية استخدام المعلومات</h2>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 bg-orange-600 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l-1 12H6L5 9z" />
                  </svg>
                </div>
                <div>
                  <h4 className="font-bold text-gray-900 mb-1">معالجة الطلبات</h4>
                  <p className="text-gray-600 text-sm">لإتمام طلبات الأضاحي والتواصل معك بخصوص الطلب</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 bg-orange-600 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                </div>
                <div>
                  <h4 className="font-bold text-gray-900 mb-1">التواصل</h4>
                  <p className="text-gray-600 text-sm">لإرسال تأكيدات الطلب وتحديثات الحالة</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 bg-orange-600 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                </div>
                <div>
                  <h4 className="font-bold text-gray-900 mb-1">تحسين الخدمة</h4>
                  <p className="text-gray-600 text-sm">لتحسين موقعنا الإلكتروني وتجربة المستخدم</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 bg-orange-600 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                  </svg>
                </div>
                <div>
                  <h4 className="font-bold text-gray-900 mb-1">الأمان</h4>
                  <p className="text-gray-600 text-sm">لحماية موقعنا ومستخدمينا من الاحتيال والأنشطة الضارة</p>
                </div>
              </div>
            </div>
          </div>

          {/* Information Sharing */}
          <div className="bg-white border border-gray-200 rounded-lg p-8 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">مشاركة المعلومات</h2>
            <div className="space-y-6">
              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">مزودي الخدمات</h3>
                <p className="text-gray-600 mb-4">
                  قد نشارك معلوماتك مع مزودي الخدمات الموثوقين الذين يساعدوننا في تشغيل موقعنا:
                </p>
                <ul className="space-y-2 text-gray-600">
                  <li className="flex items-start gap-2">
                    <span className="text-orange-600 mt-1">•</span>
                    <span>بوابات الدفع (iyzico) - لمعالجة المدفوعات</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-orange-600 mt-1">•</span>
                    <span>مزودي الاستضافة - لتشغيل موقعنا</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-orange-600 mt-1">•</span>
                    <span>مؤسسات خيرية معتمدة - لتنفيذ الأضاحي</span>
                  </li>
                </ul>
              </div>

              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">المتطلبات القانونية</h3>
                <p className="text-gray-600">
                  قد نكشف عن معلوماتك إذا كان ذلك مطلوباً بموجب القانون أو إذا كنا نعتقد بحسن نية أن هذا الإجراء ضروري لحماية حقوقنا أو حقوق الآخرين.
                </p>
              </div>

              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">عدم البيع</h3>
                <p className="text-gray-600">
                  لا نبيع أو نؤجر أو نتبادل معلوماتك الشخصية مع أطراف ثالثة لأغراض تسويقية.
                </p>
              </div>
            </div>
          </div>

          {/* Data Protection */}
          <div className="bg-green-50 rounded-lg p-8 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">حماية البيانات</h2>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <svg className="w-6 h-6 text-green-600 mt-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
                <div>
                  <h4 className="font-bold text-gray-900 mb-1">التشفير</h4>
                  <p className="text-gray-600 text-sm">نستخدم تشفير SSL لحماية البيانات أثناء النقل</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <svg className="w-6 h-6 text-green-600 mt-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <div>
                  <h4 className="font-bold text-gray-900 mb-1">الوصول المحدود</h4>
                  <p className="text-gray-600 text-sm">نحد من الوصول إلى معلوماتك الشخصية للموظفين المصرح لهم فقط</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <svg className="w-6 h-6 text-green-600 mt-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <div>
                  <h4 className="font-bold text-gray-900 mb-1">المراجعة المنتظمة</h4>
                  <p className="text-gray-600 text-sm">نراجع بانتظام ممارسات الأمان لدينا</p>
                </div>
              </div>
            </div>
          </div>

          {/* Your Rights */}
          <div className="bg-blue-50 rounded-lg p-8 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">حقوقك</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                  </svg>
                  <span className="text-gray-700 font-medium">الحق في الوصول</span>
                </div>
                <p className="text-gray-600 text-sm">طلب نسخة من معلوماتك الشخصية</p>
              </div>
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                  </svg>
                  <span className="text-gray-700 font-medium">الحق في التصحيح</span>
                </div>
                <p className="text-gray-600 text-sm">طلب تصحيح معلوماتك غير الدقيقة</p>
              </div>
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                  </svg>
                  <span className="text-gray-700 font-medium">الحق في الحذف</span>
                </div>
                <p className="text-gray-600 text-sm">طلب حذف معلوماتك الشخصية</p>
              </div>
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192L5.636 18.364M12 2.25a9.75 9.75 0 109.75 9.75A9.75 9.75 0 0012 2.25z" />
                  </svg>
                  <span className="text-gray-700 font-medium">الحق في الاعتراض</span>
                </div>
                <p className="text-gray-600 text-sm">الاعتراض على معالجة معلوماتك</p>
              </div>
            </div>
          </div>

          {/* Contact Information */}
          <div className="bg-gray-50 rounded-lg p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">معلومات الاتصال</h2>
            <p className="text-gray-600 mb-6">
              إذا كان لديك أي أسئلة حول سياسة الخصوصية هذه أو ممارساتنا في التعامل مع البيانات، يرجى التواصل معنا:
            </p>
            <div className="space-y-3">

              <div className="flex items-center gap-3">
                <svg className="w-5 h-5 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                </svg>
                <span className="text-gray-700">الهاتف: +254 750 963094</span>
              </div>
              <div className="flex items-center gap-3">
                <svg className="w-5 h-5 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
                <span className="text-gray-700">العنوان: نيروبي، كينيا</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-[#e8771b] text-white pt-10 pb-2 px-4 mt-auto">
        <div className="max-w-4xl mx-auto flex flex-col items-center text-center">
          <img src="/logo.png" alt="logo" className="w-20 h-20 mb-4 opacity-80" />
          <div className="mb-2 text-base font-normal leading-relaxed">
            تم تنفيذ هذه الخدمة من خلال شراكات موثوقة مع مؤسسات خيرية معتمدة في أفريقيا، بإشراف شرعي وقانوني.<br/>
            نحن نضمن تنفيذ الأضحية في وقتها الشرعي، وإيصالها للمستحقين بأعلى معايير الجودة والشفافية.
          </div>
          
          {/* Payment Methods */}
          <div className="flex items-center justify-center gap-4 mb-6">
            <div className="bg-white rounded-lg p-2">
              <img src="/Visa-Logo.png" alt="Visa" className="h-8 w-auto" />
            </div>
            <div className="bg-white rounded-lg p-2">
              <img src="/Mastercard-logo.svg" alt="MasterCard" className="h-8 w-auto" />
            </div>
            <div className="bg-white rounded-lg p-2">
              <img src="/pay_with_iyzico_colored.png" alt="Pay with iyzico" className="h-8 w-auto" />
            </div>
          </div>
          
          <hr className="w-full border-t border-white/60 my-6" />
          
          {/* Footer Links */}
          <div className="flex flex-wrap justify-center gap-6 mb-4 text-sm">
            <a href="/about" className="hover:underline">من نحن</a>
            <a href="/delivery" className="hover:underline">الشحن والإرجاع</a>
            <a href="/privacy" className="hover:underline">سياسة الخصوصية</a>
            <a href="/terms" className="hover:underline">الشروط والأحكام</a>
          </div>
          
          <div className="flex items-center justify-center gap-6 mb-4 text-base">
            <div className="flex items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h2.28a2 2 0 011.7 1.06l.94 1.88a2 2 0 001.7 1.06h2.28a2 2 0 011.7-1.06l.94-1.88A2 2 0 0118.72 3H21a2 2 0 012 2v14a2 2 0 01-2 2h-2.28a2 2 0 01-1.7-1.06l-.94-1.88a2 2 0 00-1.7-1.06h-2.28a2 2 0 00-1.7 1.06l-.94-1.88A2 2 0 015.28 21H3a2 2 0 01-2-2V5z" /></svg>
              +254 750 963094
            </div>
          </div>
          <div className="text-sm mt-2 opacity-90">كافة الحقوق محفوظة لمنصة اكتفاء 2025 ©</div>
        </div>
      </footer>

      {/* WhatsApp Button */}
      <WhatsAppButton />
    </div>
  );
} 