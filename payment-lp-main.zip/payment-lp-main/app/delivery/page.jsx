"use client";

import React, { useState, useRef } from "react";
import Link from "next/link";
import WhatsAppButton from "@/components/WhatsAppButton";

export default function Delivery() {
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const mobileNavRef = useRef();

  // Close mobile nav on outside click
  React.useEffect(() => {
    if (!mobileNavOpen) return;
    function handleClick(e) {
      if (mobileNavRef.current && !mobileNavRef.current.contains(e.target)) {
        setMobileNavOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, [mobileNavOpen]);

  return (
    <div className="min-h-screen flex flex-col">
      {/* Mobile Nav Button */}
      <div className="flex justify-between flex-row-reverse dir-rtl items-center px-4 pt-6 md:hidden">
        <button
          className="p-2 rounded focus:outline-none focus:ring-2 focus:ring-orange-400"
          aria-label="Open navigation menu"
          onClick={() => setMobileNavOpen(true)}
        >
          <svg className="w-8 h-8" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
        <div className="flex items-center">
          <img src="/logo.png" alt="logo" className="w-12 h-12" />
        </div>
      </div>

      {/* Desktop Nav */}
      <div className="hidden md:block w-full">
        <div className="max-w-7xl mx-auto w-full flex justify-between flex-row-reverse dir-rtl items-center px-10 pt-8">
          <div className="flex gap-10 text-lg font-medium">
            <Link href="/" className="hover:underline">الرئيسية</Link>
            <Link href="/about" className="hover:underline">من نحن</Link>
            <Link href="/delivery" className="hover:underline font-bold">الشحن والإرجاع</Link>
            <Link href="/privacy" className="hover:underline">سياسة الخصوصية</Link>
            <Link href="/terms" className="hover:underline">الشروط والأحكام</Link>
          </div>
          <div className="flex items-center w-[100px] h-[100px]">
            <img src="/logo.png" alt="logo" className="object-contain" />
          </div>
        </div>
      </div>

      {/* Mobile Nav Drawer */}
      <div
        ref={mobileNavRef}
        className={`fixed top-0 right-0 z-50 h-full w-64 bg-white text-orange-900 shadow-lg transform transition-transform duration-300 ease-in-out
          ${mobileNavOpen ? 'translate-x-0' : 'translate-x-full'}
          md:hidden dir-rtl flex flex-col`}
        style={{ fontFamily: 'inherit' }}
      >
        <div className="flex justify-between items-center p-4 border-b border-orange-100">
          <div className="flex items-center">
            <img src="/logo.png" alt="logo" className="w-12 h-12" />
          </div>
          <button
            className="p-2 rounded focus:outline-none focus:ring-2 focus:ring-orange-400"
            aria-label="Close navigation menu"
            onClick={() => setMobileNavOpen(false)}
          >
            <svg className="w-7 h-7" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <nav className="flex flex-col gap-6 text-lg font-medium p-6">
          <Link href="/" className="hover:text-orange-600 transition" onClick={() => setMobileNavOpen(false)}>الرئيسية</Link>
          <Link href="/about" className="hover:text-orange-600 transition" onClick={() => setMobileNavOpen(false)}>من نحن</Link>
          <Link href="/delivery" className="hover:text-orange-600 transition font-bold" onClick={() => setMobileNavOpen(false)}>الشحن والإرجاع</Link>
          <Link href="/privacy" className="hover:text-orange-600 transition" onClick={() => setMobileNavOpen(false)}>سياسة الخصوصية</Link>
          <Link href="/terms" className="hover:text-orange-600 transition" onClick={() => setMobileNavOpen(false)}>الشروط والأحكام</Link>
        </nav>
      </div>

      {/* Overlay when menu is open */}
      {mobileNavOpen && (
        <div
          className="fixed inset-0 z-40 bg-black bg-opacity-30 transition-opacity duration-300 md:hidden"
          onClick={() => setMobileNavOpen(false)}
        />
      )}

      {/* Main Content */}
      <div className="flex-1 bg-white">
        <div className="max-w-4xl mx-auto px-4 py-12">
          <div className="text-center mb-12">
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">شروط الشحن والإرجاع</h1>
            <div className="w-24 h-1 bg-orange-600 mx-auto"></div>
          </div>

          {/* Delivery Information */}
          <div className="bg-gray-50 rounded-lg p-8 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">معلومات التوصيل</h2>
            <div className="space-y-6">
              <div className="bg-white rounded-lg p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4">طريقة التوصيل</h3>
                <p className="text-gray-600 leading-relaxed mb-4">
                  نظراً لطبيعة خدماتنا في مجال الأضاحي، لا نقوم بشحن منتجات مادية. بدلاً من ذلك، نقوم بتنفيذ الأضحية في دول أفريقيا وتوزيعها على المستحقين.
                </p>
                <div className="grid md:grid-cols-2 gap-4 mt-4">
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-orange-600 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-white text-sm font-bold">1</span>
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900 mb-1">اختيار الأضحية</h4>
                      <p className="text-gray-600 text-sm">اختر نوع الأضحية المطلوبة من موقعنا</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-orange-600 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-white text-sm font-bold">2</span>
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900 mb-1">الدفع الإلكتروني</h4>
                      <p className="text-gray-600 text-sm">ادفع المبلغ المطلوب عبر بوابة الدفع الآمنة</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-orange-600 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-white text-sm font-bold">3</span>
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900 mb-1">التنفيذ والتوزيع</h4>
                      <p className="text-gray-600 text-sm">نقوم بذبح الأضحية وتوزيعها على المستحقين</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-orange-600 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-white text-sm font-bold">4</span>
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900 mb-1">التأكيد والإشعار</h4>
                      <p className="text-gray-600 text-sm">نرسل لك تأكيداً بالتنفيذ مع الصور والفيديو</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4">وقت التنفيذ</h3>
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <svg className="w-6 h-6 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span className="text-gray-700 font-medium">الأضاحي العادية:</span>
                    <span className="text-gray-600">خلال 24-48 ساعة من تأكيد الدفع</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <svg className="w-6 h-6 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span className="text-gray-700 font-medium">أضاحي العيد:</span>
                    <span className="text-gray-600">في أيام العيد المبارك</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <svg className="w-6 h-6 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span className="text-gray-700 font-medium">الوجبات والطرود الغذائية:</span>
                    <span className="text-gray-600">خلال 72 ساعة من تأكيد الدفع</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Return and Refund Policy */}
          <div className="bg-orange-50 rounded-lg p-8 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">سياسة الإرجاع والاسترداد</h2>
            <div className="space-y-6">
              <div className="bg-white rounded-lg p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4">شروط الاسترداد</h3>
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <svg className="w-6 h-6 text-orange-600 mt-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <div>
                      <h4 className="font-bold text-gray-900 mb-1">قبل التنفيذ</h4>
                      <p className="text-gray-600 text-sm">يمكن طلب الاسترداد الكامل قبل بدء عملية الذبح</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <svg className="w-6 h-6 text-orange-600 mt-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
                    </svg>
                    <div>
                      <h4 className="font-bold text-gray-900 mb-1">بعد التنفيذ</h4>
                      <p className="text-gray-600 text-sm">لا يمكن الاسترداد بعد بدء عملية الذبح أو التوزيع</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <svg className="w-6 h-6 text-orange-600 mt-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <div>
                      <h4 className="font-bold text-gray-900 mb-1">الأخطاء التقنية</h4>
                      <p className="text-gray-600 text-sm">في حالة حدوث خطأ تقني، سيتم الاسترداد الكامل خلال 5-7 أيام عمل</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4">إجراءات الاسترداد</h3>
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-orange-600 rounded-full flex items-center justify-center text-white font-bold">1</div>
                    <span className="text-gray-700">تواصل معنا عبر البريد الإلكتروني أو الهاتف</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-orange-600 rounded-full flex items-center justify-center text-white font-bold">2</div>
                    <span className="text-gray-700">قدم رقم الطلب وسبب الاسترداد</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-orange-600 rounded-full flex items-center justify-center text-white font-bold">3</div>
                    <span className="text-gray-700">سنراجع طلبك ونوافيك بالنتيجة خلال 24 ساعة</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-orange-600 rounded-full flex items-center justify-center text-white font-bold">4</div>
                    <span className="text-gray-700">في حالة الموافقة، سيتم الاسترداد خلال 5-7 أيام عمل</span>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4">معلومات الاتصال للاسترداد</h3>
                <div className="space-y-3">

                  <div className="flex items-center gap-3">
                    <svg className="w-5 h-5 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                    </svg>
                    <span className="text-gray-700">الهاتف: +254 750 963094</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <svg className="w-5 h-5 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span className="text-gray-700">أوقات العمل: الأحد - الخميس (8:00 ص - 6:00 م)</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Important Notes */}
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
            <h3 className="text-xl font-bold text-yellow-800 mb-4">ملاحظات مهمة</h3>
            <ul className="space-y-2 text-yellow-700">
              <li className="flex items-start gap-2">
                <span className="text-yellow-600 mt-1">•</span>
                <span>جميع الأضاحي يتم ذبحها وفق المعايير الشرعية الإسلامية</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-yellow-600 mt-1">•</span>
                <span>نقوم بتوثيق عملية الذبح والتوزيع بالصور والفيديو</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-yellow-600 mt-1">•</span>
                <span>نضمن وصول الأضاحي للمستحقين في الوقت المناسب</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-yellow-600 mt-1">•</span>
                <span>في حالة عدم إمكانية التنفيذ، سيتم إعادة المبلغ كاملاً</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-[#e8771b] text-white pt-10 pb-2 px-4 mt-auto">
        <div className="max-w-4xl mx-auto flex flex-col items-center text-center">
          <img src="/logo.png" alt="logo" className="w-20 h-20 mb-4 opacity-80" />
          <div className="mb-2 text-base font-normal leading-relaxed">
            تم تنفيذ هذه الخدمة من خلال شراكات موثوقة مع مؤسسات خيرية معتمدة في أفريقيا، بإشراف شرعي وقانوني.<br/>
            نحن نضمن تنفيذ الأضحية في وقتها الشرعي، وإيصالها للمستحقين بأعلى معايير الجودة والشفافية.
          </div>
          
          {/* Payment Methods */}
          <div className="flex items-center justify-center gap-4 mb-6">
            <div className="bg-white rounded-lg p-2">
              <img src="/Visa-Logo.png" alt="Visa" className="h-8 w-auto" />
            </div>
            <div className="bg-white rounded-lg p-2">
              <img src="/Mastercard-logo.svg" alt="MasterCard" className="h-8 w-auto" />
            </div>
            <div className="bg-white rounded-lg p-2">
              <img src="/pay_with_iyzico_colored.png" alt="Pay with iyzico" className="h-8 w-auto" />
            </div>
          </div>
          
          <hr className="w-full border-t border-white/60 my-6" />
          
          {/* Footer Links */}
          <div className="flex flex-wrap justify-center gap-6 mb-4 text-sm">
            <a href="/about" className="hover:underline">من نحن</a>
            <a href="/delivery" className="hover:underline">الشحن والإرجاع</a>
            <a href="/privacy" className="hover:underline">سياسة الخصوصية</a>
            <a href="/terms" className="hover:underline">الشروط والأحكام</a>
          </div>
          
          <div className="flex items-center justify-center gap-6 mb-4 text-base">
            <div className="flex items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h2.28a2 2 0 011.7 1.06l.94 1.88a2 2 0 001.7 1.06h2.28a2 2 0 011.7-1.06l.94-1.88A2 2 0 0118.72 3H21a2 2 0 012 2v14a2 2 0 01-2 2h-2.28a2 2 0 01-1.7-1.06l-.94-1.88a2 2 0 00-1.7-1.06h-2.28a2 2 0 00-1.7 1.06l-.94-1.88A2 2 0 015.28 21H3a2 2 0 01-2-2V5z" /></svg>
              +254 750 963094
            </div>
          </div>
          <div className="text-sm mt-2 opacity-90">كافة الحقوق محفوظة لمنصة اكتفاء 2025 ©</div>
        </div>
      </footer>

      {/* WhatsApp Button */}
      <WhatsAppButton />
    </div>
  );
} 