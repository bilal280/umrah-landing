"use client";

import { useState, useRef } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import PhoneInput from "../components/PhoneInput";
import CountryDropdown from "../components/CountryDropdown";
import FormInput from "../components/FormInput";
import FormSelect from "../components/FormSelect";
import CartItem from "../components/CartItem";
import { useCart } from "../lib/cartContext";
import React from "react";
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";
import WhatsAppButton from "@/components/WhatsAppButton";

const PRODUCTS = [
  {
    id: "sheep",
    name: "خاروف",
    image: "/sheep.png",
    price: "$75",
    age: "سنة",
    health: "ممتازة",
    weight: "60 kg",
  },
  {
    id: "calf",
    name: "عجل",
    image: "/calf.png",
    price: "$450",
    age: "سنتين",
    health: "ممتازة",
    weight: "200 kg",
  },
  {
    id: "camel",
    name: "جمل",
    image: "/camel.png",
    price: "$750",
    age: "ثلاث سنوات",
    health: "ممتازة",
    weight: "300 kg",
  },
  {
    id: "meal",
    name: "الوجبة",
    image: "/meal.png",
    price: "$2",
    age: "—",
    health: "—",
    weight: "—",
  },
  {
    id: "foodbox",
    name: "الطرد الغذائي",
    image: "/foodbox.png",
    price: "—",
    age: "—",
    health: "—",
    weight: "—",
  },
];

export default function Home() {
  const router = useRouter();
  const { items, addToCart, getTotalItems, getTotalPrice } = useCart();
  const [form, setForm] = useState({
    name: "",
    email: "",
    country: "",
    phone: "",
    behalf: "عن نفسي",
  });
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);
  const [successProduct, setSuccessProduct] = useState("");

  // Mobile nav state
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const mobileNavRef = useRef();

  // Close mobile nav on outside click
  React.useEffect(() => {
    if (!mobileNavOpen) return;
    function handleClick(e) {
      if (mobileNavRef.current && !mobileNavRef.current.contains(e.target)) {
        setMobileNavOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, [mobileNavOpen]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((f) => ({ ...f, [name]: value }));
  };

  const handleCountryChange = (country) => {
    setForm((f) => ({ ...f, country }));
  };

  const handlePhoneChange = (phone) => {
    setForm((f) => ({ ...f, phone }));
  };

  const handleAddToCart = (product) => {
    addToCart(product, 1);
    setSuccessProduct(product.name);
    setShowSuccessMessage(true);
    
    // Hide success message after 3 seconds
    setTimeout(() => {
      setShowSuccessMessage(false);
    }, 3000);
  };

  const scrollToCart = () => {
    const orderSection = document.getElementById('order');
    if (orderSection) {
      orderSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Validation functions
  const validateName = (value) => {
    if (!value || value.trim().length < 2) {
      return { isValid: false, message: "يجب أن يكون الاسم أكثر من حرفين" };
    }
    if (value.trim().length > 50) {
      return { isValid: false, message: "يجب أن يكون الاسم أقل من 50 حرف" };
    }
    return { isValid: true, message: "" };
  };

  const validateEmail = (value) => {
    if (!value) {
      return { isValid: false, message: "يرجى إدخال البريد الإلكتروني" };
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(value)) {
      return { isValid: false, message: "يرجى إدخال بريد إلكتروني صحيح" };
    }
    return { isValid: true, message: "" };
  };

  const validateCountry = (value) => {
    if (!value) {
      return { isValid: false, message: "يرجى اختيار البلد" };
    }
    return { isValid: true, message: "" };
  };

  const validatePhone = (value) => {
    if (!value) {
      return { isValid: false, message: "يرجى إدخال رقم الهاتف" };
    }
    if (value.length < 8) {
      return { isValid: false, message: "يجب أن يكون رقم الهاتف صحيح" };
    }
    return { isValid: true, message: "" };
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Check if cart is empty
    if (items.length === 0) {
      alert("يرجى إضافة منتجات إلى السلة أولاً");
      return;
    }
    
    // Validate all fields before submission
    const nameValidation = validateName(form.name);
    const emailValidation = validateEmail(form.email);
    const countryValidation = validateCountry(form.country);
    const phoneValidation = validatePhone(form.phone);

    if (!nameValidation.isValid || !emailValidation.isValid || !countryValidation.isValid || !phoneValidation.isValid) {
      return; // Don't submit if validation fails
    }

    // Create cart data for checkout
    const cartData = {
      items: items,
      total: getTotalPrice(),
      customerInfo: form
    };

    // Navigate to checkout with cart data
    router.push(`/checkout?data=${encodeURIComponent(JSON.stringify(cartData))}`);
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Success Message */}
      {showSuccessMessage && (
        <div className="fixed top-4 left-4 right-4 z-50 bg-green-500 text-white p-4 rounded-lg shadow-lg transform transition-all duration-300 animate-slideIn">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
              </svg>
              <span className="font-bold">تم إضافة {successProduct} إلى السلة بنجاح!</span>
            </div>
            <button
              onClick={() => setShowSuccessMessage(false)}
              className="text-white hover:text-gray-200 transition"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>
      )}

      {/* Floating Cart Icon - Mobile Only */}
      {getTotalItems() > 0 && (
        <div className="fixed bottom-6 left-6 z-40 md:hidden">
          <button
            onClick={scrollToCart}
            className="bg-orange-600 hover:bg-orange-700 text-white p-4 rounded-full shadow-lg transition-all duration-300 transform hover:scale-110"
            aria-label="انتقل إلى السلة"
          >
            <div className="relative">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l-1 12H6L5 9z" />
              </svg>
              <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold">
                {getTotalItems()}
              </span>
            </div>
          </button>
        </div>
      )}

      {/* Hero Section */}
      <section
        className="relative hero-section min-h-[480px] md:min-h-[600px] flex flex-col justify-between text-white px-0"
      >
        {/* Light overlay for mobile only */}
        <div className="absolute inset-0 block md:hidden pointer-events-none z-10" style={{ background: 'rgba(249, 115, 22, 0.3)' }}></div>
        <div className="relative z-20">
        {/* Mobile Nav Button */}
        <div className="flex justify-between flex-row-reverse dir-rtl items-center px-4 pt-6 md:hidden">
          <button
            className="p-2 rounded focus:outline-none focus:ring-2 focus:ring-orange-400"
            aria-label="Open navigation menu"
            onClick={() => setMobileNavOpen(true)}
          >
            <svg className="w-8 h-8" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
          <div className="flex items-center">
            <img src="/logo.png" alt="logo" className="w-12 h-12" />
          </div>
        </div>

        {/* Desktop Nav */}
        <div className="hidden md:block w-full">
          <div className="max-w-7xl mx-auto w-full flex justify-between flex-row-reverse dir-rtl items-center px-10 pt-8">
            <div className="flex gap-10 text-lg font-medium">
              <a href="#" className="hover:underline">الرئيسية</a>
              <a href="#products" className="hover:underline">أنواع الأضاحي</a>
              <a href="#order" className="hover:underline">طلب أضحية</a>
              <a href="/about" className="hover:underline">من نحن</a>
              <a href="/delivery" className="hover:underline">الشحن والإرجاع</a>
            </div>
            <div className="flex items-center w-[100px] h-[100px]">
              <img src="/logo.png" alt="logo" className=" object-contain" />
            </div>
          </div>
        </div>

        {/* Mobile Nav Drawer */}
        <div
          ref={mobileNavRef}
          className={`fixed top-0 right-0 z-50 h-full w-64 bg-white text-orange-900 shadow-lg transform transition-transform duration-300 ease-in-out
            ${mobileNavOpen ? 'translate-x-0' : 'translate-x-full'}
            md:hidden dir-rtl flex flex-col`}
          style={{ fontFamily: 'inherit' }}
        >
          <div className="flex justify-between items-center p-4 border-b border-orange-100">
            <div className="flex items-center">
              <img src="/logo.png" alt="logo" className="w-12 h-12" />
            </div>
            <button
              className="p-2 rounded focus:outline-none focus:ring-2 focus:ring-orange-400"
              aria-label="Close navigation menu"
              onClick={() => setMobileNavOpen(false)}
            >
              <svg className="w-7 h-7" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          <nav className="flex flex-col gap-6 text-lg font-medium p-6">
            <a href="#" className="hover:text-orange-600 transition" onClick={() => setMobileNavOpen(false)}>الرئيسية</a>
            <a href="#products" className="hover:text-orange-600 transition" onClick={() => setMobileNavOpen(false)}>أنواع الأضاحي</a>
            <a href="#order" className="hover:text-orange-600 transition" onClick={() => setMobileNavOpen(false)}>طلب أضحية</a>
            <a href="/about" className="hover:text-orange-600 transition" onClick={() => setMobileNavOpen(false)}>من نحن</a>
            <a href="/delivery" className="hover:text-orange-600 transition" onClick={() => setMobileNavOpen(false)}>الشحن والإرجاع</a>
          </nav>
        </div>

        {/* Overlay when menu is open */}
        {mobileNavOpen && (
          <div
            className="fixed inset-0 z-40 bg-black bg-opacity-30 transition-opacity duration-300 md:hidden"
            onClick={() => setMobileNavOpen(false)}
          />
        )}

    
        {/* Main hero content */}
        <div className="flex flex-col md:flex-row justify-between items-center w-full max-w-7xl mx-auto px-10 py-16 md:py-24">
          <div className="flex-1 flex flex-col items-start text-right dir-rtl">
            <h1 className="text-3xl md:text-5xl font-bold mb-6 leading-relaxed">اختر أضحيتك الآن وشارك الأجر في دول أفريقيا</h1>
            <p className="mb-8 text-lg max-w-xl">وفرنا لك خدمة إلكترونية متكاملة تمكّنك من اختيار نوع الأضحية (خروف، بقرة، جمل)، إدخال بياناتك، تحديد العدد، والدفع الإلكتروني بأمان تام.<br />سيتم ذبح الأضحية في دول أفريقية محتاجة وتوزيعها على الفقراء والمساكين خلال أيام العيد، مع إشراف شرعي وتنفيذي موثوق.</p>
            <a href="#order" className="bg-orange-900 hover:bg-orange-800 text-white font-bold py-2 px-8 rounded transition text-lg">ابدأ الآن</a>
          </div>
          <div className="flex-1 hidden md:block"></div>
        </div>
        {/* <img src="/" alt="" className="w-full img-hero h-full object-cover block md:hidden" /> */}
        </div>
      </section>

      {/* Products Section */}
      <section className="py-12 px-4 bg-white" id="products">
        <div className="max-w-4xl mx-auto text-center mb-10">
          <h2 className="text-2xl font-bold mb-2">أنواع الأضاحي المتاحة</h2>
          <p className="text-gray-600">نحن نعمل مع فرق محلية في دول أفريقيا لتوفير أضاحي شرعية ومضمونة لذبح وتوزيعها على مستحقيها بإشراف شرعي كامل.</p>
        </div>
        {/* Mobile: stacked cards */}
        <div className="flex flex-col gap-6 max-w-md mx-auto md:hidden">
          {PRODUCTS.map((p) => (
            <div
              key={p.id}
              className="bg-white rounded-lg shadow-md p-6 flex flex-col items-center"
              style={{ minWidth: '0', maxWidth: '100%' }}
            >
              <div className="w-full aspect-square mb-4 overflow-hidden rounded-lg">
                <Image src={p.image} alt={p.name} width={320} height={320} className="object-cover w-full h-full" />
              </div>
              <h3 className="font-bold text-2xl mb-2 text-center">{p.name}</h3>
              <div className="text-gray-800 text-md mb-4 text-center leading-relaxed">
                <div><span className="font-bold">العمر :</span> {p.age}</div>
                <div><span className="font-bold">الحالة الصحية :</span> {p.health}</div>
                <div><span className="font-bold">الوزن :</span> {p.weight}</div>
              </div>
              <div className="font-bold text-orange-600 text-2xl mb-4">{p.price}</div>
              <button
                onClick={() => handleAddToCart(p)}
                className="bg-orange-600 hover:bg-orange-700 text-white font-bold py-2 px-6 rounded-lg transition-all duration-200 transform hover:scale-105"
              >
                إضافة إلى السلة
              </button>
            </div>
          ))}
        </div>
        {/* Desktop/Tablet: carousel */}
        <div className="max-w-5xl mx-auto justify-center items-center hidden md:block">
          <Carousel
            additionalTransfrom={0}
            arrows
            autoPlaySpeed={4000}
            centerMode={false}
            className=""
            containerClass="carousel-container"
            dotListClass=""
            draggable
            focusOnSelect={false}
            infinite={false}
            itemClass="px-2"
            keyBoardControl
            minimumTouchDrag={80}
            renderButtonGroupOutside={false}
            renderDotsOutside={false}
            responsive={{
              superLargeDesktop: { breakpoint: { max: 4000, min: 1280 }, items: 3 },
              desktop: { breakpoint: { max: 1280, min: 900 }, items: 3 },
              tablet: { breakpoint: { max: 900, min: 640 }, items: 2 },
              mobile: { breakpoint: { max: 640, min: 0 }, items: 1 },
            }}
            showDots={false}
            sliderClass=""
            slidesToSlide={1}
            swipeable
            rtl={true}
          >
            {PRODUCTS.map((p) => (
              <div
                key={p.id}
                className="bg-white rounded-lg shadow-md p-6 w-80 flex-shrink-0 flex flex-col items-center mx-2"
                style={{ minWidth: '320px', maxWidth: '320px' }}
              >
                <div className="w-full aspect-square mb-4 overflow-hidden rounded-lg">
                  <Image src={p.image} alt={p.name} width={320} height={320} className="object-cover w-full h-full" />
                </div>
                <h3 className="font-bold text-2xl mb-2 text-center">{p.name}</h3>
                <div className="text-gray-800 text-md mb-4 text-center leading-relaxed">
                  <div><span className="font-bold">العمر :</span> {p.age}</div>
                  <div><span className="font-bold">الحالة الصحية :</span> {p.health}</div>
                  <div><span className="font-bold">الوزن :</span> {p.weight}</div>
                </div>
                <div className="font-bold text-orange-600 text-2xl mb-4">{p.price}</div>
                <button
                  onClick={() => handleAddToCart(p)}
                  className="bg-orange-600 hover:bg-orange-700 text-white font-bold py-2 px-6 rounded-lg transition-all duration-200 transform hover:scale-105"
                >
                  إضافة إلى السلة
                </button>
              </div>
            ))}
          </Carousel>
        </div>
      </section>

      {/* Order Form Section */}
      <section className="py-12 px-4 bg-gray-50" id="order">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-xl font-bold mb-6 text-center">املأ بياناتك لإتمام الطلب</h2>
          
          {/* Cart Items */}
          {items.length > 0 && (
            <div className="mb-8 bg-white p-6 rounded-lg shadow">
              <h3 className="text-lg font-bold mb-4">المنتجات المختارة</h3>
              <div className="space-y-4">
                {items.map((item) => (
                  <CartItem key={item.id} item={item} />
                ))}
              </div>
              <div className="mt-6 pt-4 border-t border-gray-200">
                <div className="flex justify-between items-center">
                  <span className="text-lg font-bold">المجموع:</span>
                  <span className="text-2xl font-bold text-orange-600">${getTotalPrice().toFixed(2)}</span>
                </div>
              </div>
            </div>
          )}

          {/* Personal Information Form */}
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-bold mb-4">المعلومات الشخصية</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="animate-slideIn">
                <label className="block mb-1 font-medium text-gray-700">الاسم الكامل</label>
                <FormInput
                  name="name"
                  value={form.name}
                  onChange={handleChange}
                  placeholder="الاسم الكامل"
                  required
                  validation={validateName}
                />
              </div>
              <div className="animate-slideIn" style={{ animationDelay: '0.1s' }}>
                <label className="block mb-1 font-medium text-gray-700">البريد الإلكتروني</label>
                <FormInput
                  name="email"
                  type="email"
                  value={form.email}
                  onChange={handleChange}
                  placeholder="example@email.com"
                  required
                  validation={validateEmail}
                />
              </div>
              <div className="animate-slideIn" style={{ animationDelay: '0.2s' }}>
                <label className="block mb-1 font-medium text-gray-700">البلد</label>
                <CountryDropdown 
                  value={form.country} 
                  onChange={handleCountryChange}
                  validation={validateCountry}
                />
              </div>
              <div className="animate-slideIn" style={{ animationDelay: '0.3s' }}>
                <label className="block mb-1 font-medium text-gray-700">رقم الهاتف</label>
                <PhoneInput 
                  value={form.phone} 
                  onChange={handlePhoneChange}
                  validation={validatePhone}
                />
              </div>
              <div className="animate-slideIn" style={{ animationDelay: '0.4s' }}>
                <label className="block mb-1 font-medium text-gray-700">نية الذبح</label>
                <FormSelect
                  name="behalf"
                  value={form.behalf}
                  onChange={handleChange}
                  options={[
                    { value: "عن نفسي", label: "عن نفسي" },
                    { value: "عن الغير", label: "عن الغير" }
                  ]}
                />
              </div>
              <button 
                type="submit" 
                className="w-full bg-orange-700 hover:bg-orange-800 text-white font-bold py-3 px-6 rounded-lg transition-all duration-200 transform hover:scale-[1.02] hover:shadow-lg animate-slideIn"
                style={{ animationDelay: '0.5s' }}
              >
                متابعة إلى الدفع
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#e8771b] text-white pt-10 pb-2 px-4 mt-auto">
        <div className="max-w-4xl mx-auto flex flex-col items-center text-center">
          <img src="/logo.png" alt="logo" className="w-20 h-20 mb-4 opacity-80" />
          <div className="mb-2 text-base font-normal leading-relaxed">
            تم تنفيذ هذه الخدمة من خلال شراكات موثوقة مع مؤسسات خيرية معتمدة في أفريقيا، بإشراف شرعي وقانوني.<br/>
            نحن نضمن تنفيذ الأضحية في وقتها الشرعي، وإيصالها للمستحقين بأعلى معايير الجودة والشفافية.
          </div>
          
          {/* Payment Methods */}
          <div className="flex items-center justify-center gap-4 mb-6">
            <div className="bg-white rounded-lg p-2">
              <img src="/Visa-Logo.png" alt="Visa" className="h-8 w-auto" />
            </div>
            <div className="bg-white rounded-lg p-2">
              <img src="/Mastercard-logo.svg" alt="MasterCard" className="h-8 w-auto" />
            </div>
            <div className="bg-white rounded-lg p-2">
              <img src="/pay_with_iyzico_colored.png" alt="Pay with iyzico" className="h-8 w-auto" />
            </div>
          </div>
          
          <hr className="w-full border-t border-white/60 my-6" />
          
          {/* Footer Links */}
          <div className="flex flex-wrap justify-center gap-6 mb-4 text-sm">
            <a href="/about" className="hover:underline">من نحن</a>
            <a href="/delivery" className="hover:underline">الشحن والإرجاع</a>
            <a href="/privacy" className="hover:underline">سياسة الخصوصية</a>
            <a href="/terms" className="hover:underline">الشروط والأحكام</a>
          </div>
          
          <div className="flex items-center justify-center gap-6 mb-4 text-base">
            <div className="flex items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h2.28a2 2 0 011.7 1.06l.94 1.88a2 2 0 001.7 1.06h2.28a2 2 0 011.7-1.06l.94-1.88A2 2 0 0118.72 3H21a2 2 0 012 2v14a2 2 0 01-2 2h-2.28a2 2 0 01-1.7-1.06l-.94-1.88a2 2 0 00-1.7-1.06h-2.28a2 2 0 00-1.7 1.06l-.94-1.88A2 2 0 015.28 21H3a2 2 0 01-2-2V5z" /></svg>
              +254 750 963094
            </div>
          </div>
          <div className="text-sm mt-2 opacity-90">كافة الحقوق محفوظة لمنصة اكتفاء 2025 ©</div>
        </div>
      </footer>

      {/* WhatsApp Button */}
      <WhatsAppButton />
    </div>
  );
}
