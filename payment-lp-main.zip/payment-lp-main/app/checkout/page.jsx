"use client";
import { useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import Image from "next/image";
import PaymentForm from "../../components/PaymentForm";
import CartItem from "../../components/CartItem";
import SSLVerification from "../../components/SSLVerification";

function CheckoutContent() {
  const params = useSearchParams();
  const [loading, setLoading] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  
  // Parse cart data from URL
  let cartData = null;
  try {
    const dataParam = params.get("data");
    if (dataParam) {
      cartData = JSON.parse(decodeURIComponent(dataParam));
    }
  } catch (error) {
    console.error("Error parsing cart data:", error);
  }

  if (!cartData) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center py-10 px-4">
        <div className="bg-white rounded-lg shadow-lg p-8 w-full max-w-xl text-center">
          <h1 className="text-2xl font-bold mb-4 text-red-600">خطأ في البيانات</h1>
          <p className="text-gray-600 mb-6">لم يتم العثور على بيانات الطلب. يرجى العودة إلى الصفحة الرئيسية وإعادة المحاولة.</p>
          <a href="/" className="bg-orange-600 hover:bg-orange-700 text-white font-bold py-2 px-6 rounded transition">
            العودة للصفحة الرئيسية
          </a>
        </div>
      </div>
    );
  }

  const { items, total, customerInfo } = cartData;

  const handlePayment = async (paymentData) => {
    setLoading(true);
    
    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // In a real application, you would send the payment data to your payment processor
    console.log("Payment data:", paymentData);
    console.log("Order data:", cartData);
    
    setLoading(false);
    setPaymentSuccess(true);
  };

  if (paymentSuccess) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center py-10 px-4">
        <div className="bg-white rounded-lg shadow-lg p-8 w-full max-w-xl text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h1 className="text-2xl font-bold mb-4 text-green-600">تم الدفع بنجاح!</h1>
          <p className="text-gray-600 mb-6">شكراً لك على تبرعك. سيتم إرسال تأكيد الطلب إلى بريدك الإلكتروني قريباً.</p>
          <div className="bg-gray-50 p-4 rounded-lg mb-6">
            <h3 className="font-bold mb-2">تفاصيل الطلب:</h3>
            <p className="text-sm text-gray-600">رقم الطلب: #{Math.random().toString(36).substr(2, 9).toUpperCase()}</p>
            <p className="text-sm text-gray-600">المجموع: ${total.toFixed(2)}</p>
          </div>
          <a href="/" className="bg-orange-600 hover:bg-orange-700 text-white font-bold py-2 px-6 rounded transition">
            العودة للصفحة الرئيسية
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-10 px-4">
      <div className="max-w-4xl mx-auto">
        <SSLVerification />
        <h1 className="text-3xl font-bold mb-8 text-center">مراجعة الطلب والدفع</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Order Summary */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-xl font-bold mb-6">ملخص الطلب</h2>
            
            {/* Customer Information */}
            <div className="mb-6 p-4 bg-gray-50 rounded-lg">
              <h3 className="font-bold mb-3">المعلومات الشخصية</h3>
              <div className="space-y-2 text-sm">
                <div><span className="font-medium">الاسم:</span> {customerInfo.name}</div>
                <div><span className="font-medium">البريد الإلكتروني:</span> {customerInfo.email}</div>
                <div><span className="font-medium">البلد:</span> {customerInfo.country}</div>
                <div><span className="font-medium">رقم الهاتف:</span> {customerInfo.phone}</div>
                <div><span className="font-medium">نية الذبح:</span> {customerInfo.behalf}</div>
              </div>
            </div>

            {/* Cart Items */}
            <div className="mb-6">
              <h3 className="font-bold mb-4">المنتجات المختارة</h3>
              <div className="space-y-4">
                {items.map((item) => (
                  <div key={item.id} className="flex items-center gap-4 p-3 bg-gray-50 rounded-lg">
                    <div className="w-12 h-12 relative flex-shrink-0">
                      <Image 
                        src={item.image} 
                        alt={item.name} 
                        width={48} 
                        height={48} 
                        className="object-cover rounded"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-bold text-sm">{item.name}</h4>
                      <div className="text-xs text-gray-600">
                        <div>العمر: {item.age}</div>
                        <div>الحالة الصحية: {item.health}</div>
                        <div>الوزن: {item.weight}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-sm">${parseFloat(item.price.replace('$', ''))}</div>
                      <div className="text-xs text-gray-600">الكمية: {item.quantity}</div>
                      <div className="font-bold text-orange-600">
                        ${(parseFloat(item.price.replace('$', '')) * item.quantity).toFixed(2)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Total */}
            <div className="border-t border-gray-200 pt-4">
              <div className="flex justify-between items-center">
                <span className="text-lg font-bold">المجموع:</span>
                <span className="text-2xl font-bold text-orange-600">${total.toFixed(2)}</span>
              </div>
            </div>
          </div>

          {/* Payment Form */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-xl font-bold mb-6">معلومات الدفع</h2>
            <PaymentForm onSubmit={handlePayment} loading={loading} />
            
            {/* Payment Methods */}
            <div className="mt-6 p-4 bg-gray-50 rounded-lg">
              <h3 className="font-bold text-gray-800 mb-3">طرق الدفع المقبولة</h3>
              <div className="flex items-center gap-4">
                <div className="bg-white rounded-lg p-2 border">
                  <img src="/Visa-Logo.png" alt="Visa" className="h-8 w-auto" />
                </div>
                <div className="bg-white rounded-lg p-2 border">
                  <img src="/Mastercard-logo.svg" alt="MasterCard" className="h-8 w-auto" />
                </div>
                <div className="bg-white rounded-lg p-2 border">
                  <img src="/pay_with_iyzico_colored.png" alt="Pay with iyzico" className="h-8 w-auto" />
                </div>
              </div>
            </div>
            
            <div className="mt-6 p-4 bg-blue-50 rounded-lg">
              <h3 className="font-bold text-blue-800 mb-2">معلومات الأمان</h3>
              <p className="text-sm text-blue-700">
                جميع المعاملات محمية بتقنية التشفير SSL. لن يتم تخزين بيانات البطاقة على خوادمنا.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function LoadingFallback() {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center py-10 px-4">
      <div className="bg-white rounded-lg shadow-lg p-8 w-full max-w-xl">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded mb-6"></div>
          <div className="space-y-4">
            <div className="h-4 bg-gray-200 rounded"></div>
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Checkout() {
  return (
    <Suspense fallback={<LoadingFallback />}>
      <CheckoutContent />
    </Suspense>
  );
} 